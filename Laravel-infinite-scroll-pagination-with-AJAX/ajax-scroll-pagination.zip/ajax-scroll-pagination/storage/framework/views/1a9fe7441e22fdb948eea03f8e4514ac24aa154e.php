<?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
    <div>
        <h3><a href=""><?php echo e($blog->title); ?></a></h3>
        <p><?php echo e(str_limit($blog->description, 400)); ?></p>

        <div class="text-right">
            <button class="btn btn-success">Read More</button>
        </div>

        <hr style="margin-top:5px;">
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>